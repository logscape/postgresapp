
// compare :  el.subString(comm) == true 

def listSubstringContains(list,pattern){
	println "List - $list"
	println "Pattern - $pattern"
	def retValue = false
	list.each{ line->
		if (line.contains(pattern) == true)
		{
			retValue = true 			
		}
	}
	return retValue;
} 


def comm="chrome"
def filters=["chrome.exe"]
println listSubstringContains(filters,comm)

/*
filters.each{ line->
	if (line.contains(comm))
		println "contains"
}


println filters*/