echo " cleaning [ queries] " 

rm ./lib/*.class
rm ./lib/queries.jar 
rm *.class 
echo " building [queries.jar] " 

groovyc -cp ./lib/app.jar:./lib/postgresql-9.3-1102.jdbc41.jar:./lib/serviceUtils.jar  queries.groovy
mv *.class lib 
cd lib 
jar cvf queries.jar  ConnectionDetails.class QueryLogger*.class RowHelper.class

