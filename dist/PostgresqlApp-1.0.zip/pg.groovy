
class DBServerInfo {
	def hostname 
	def user
	def password 
	def url 
	def sql
	def DBServerInfo(user,password,hostname,sql){
		this.hostname=hostname
		this.password=password
		this.url=url
		this.sql=sql
	}
}


