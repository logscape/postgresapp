import java.text.SimpleDateFormat 

pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def stdOut = pout
def stdErr = perr

Logger logger = new Logger()
logger.setOutStream(pout)
logger.setErrStream(perr)

def propertyMissing(String name) {}
def arguments  =  args  as List 
def properties= null;

def shellCommandExecutor(cmdString){
	def cmd=[ "bash" , "-c", cmdString.stripMargin()  ]
	return cmd.execute().text.split("\n")
}

def winCommandExecutor(cmdString){
	return cmdString.execute().text
}

if (arguments!=null) {
	properties=new ExecutionContext(arguments) 
}else{
	properties=new ExecutionContext(arguments,_bindings) 
}

appProperties=new ExecutionContext( arguments.findAll { it[0] == '_' } ) 

def appname=properties.map["bundleId"].split("-")[0].toLowerCase()

if ( properties.map.containsKey("_filter")== false ) {
	logger.error(" Requires a comma separated app filter  " ) 
}

def appNameFilters=properties.map["_filter"].split(",") 


def listContainsPattern(list,pattern){	
	def retValue = false
	list.each{ line->
		if (pattern.contains(line) == true)
		{
			retValue = true 			
		}
	}
	return retValue;
}

def processHashMap=[:]

if (System.properties['os.name'].toLowerCase().contains('windows')) {
	winCommandExecutor("cmd /c cscript.exe listProcesses.vbs").eachLine{ line->
		if (line.contains("/")){
			tokens=line.split(/,/)
			pid=tokens[3]
			comm=tokens[2]
			if (listContainsPattern(appNameFilters,comm)) {
				processHashMap[pid] = ["_":"_", "appname":appname , "metric":"proc"]
				processHashMap[pid]["pid"]=tokens[3]
				processHashMap[pid]["pcpu"]=tokens[4]
				processHashMap[pid]["pmem"]=tokens[5]
				processHashMap[pid]["comm"]=tokens[2]
			}

		}
		
	}
} else {	
	shellCommandExecutor("ps -wweo uname,pid,psr,pcpu,cputime,pmem,rsz,vsz,tty,s,etime,comm").each{ line -> 
		toks=line.split(/\s+/)
		pid=toks[1] 
		comm=toks[-1]
		if (appNameFilters.contains(comm)) { 
			processHashMap[pid] = ["_":"_", "appname":appname , "metric":"proc"] 	
			processHashMap[pid]["pid"]=toks[1]
			processHashMap[pid]["pcpu"]=toks[3]
			processHashMap[pid]["pmem"]=toks[5]
			processHashMap[pid]["rss"]=toks[6]
			processHashMap[pid]["comm"]=toks[-1]
		}
	}
}


processHashMap.keySet().each{ k -> 
	logger.logkv(processHashMap[k]) 
}


