

def map=["name":"booby","age":"13"]
def oldmap=["age":"14","name":"booby"] 

println MetricDiffOp.go(oldmap,map) 
println MetricDiffOp.go(map,map) 


public class MetricFlattenOp {
	public static def go(map,parent=null){ 
		def fMap = [:] 
		for (def k:  map.keySet()){
			def v  = map[k]
			if(map[k] instanceof java.util.HashMap){
				fMap=fMap + go(v,parent=k) 
				continue 
			}
			if (parent != null){
				k = parent + "." + k 
			}
			fMap[k] = v 
		}

		return fMap; 
	}


}

public class MetricDiffOp { 
	public static def go(map1,map2,deltaFields=[]){
		
		def diff=[:] 
		def a = null
		def b = null 
		if (map1.keySet().size() > map2.keySet().size() )  {
			a  = map1 
			b  = map2 
		}else{
			a = map2 
			b = map1 
		}
		for(def key: a.keySet() ){
			if (map1[key] != map2[key]){	
				try { map1[key] = map1[key].toLong();  } catch (Exception e) { map1[key] ; } 
				try { map2[key] = map2[key].toLong();  } catch (Exception e) { map2[key] ; } 

				if (map1[key] instanceof String){
					diff[key]=map2[key] 
				}
				if (map1[key] instanceof Long){
					def value= map2[key] - map1[key]
					if (value != 0 ) {
						diff[key+"Delta"]=value ;				
					}
				}


			} 
			//numbers return the delta 
			
		}
		return diff
	}
}


