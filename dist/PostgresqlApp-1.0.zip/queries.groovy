import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import groovy.sql.Sql


/*
pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def propertyMissing(String name) {}
def stdOut = pout
def stdErr = perr
Logger logger = new Logger()
logger.setOutStream(pout)
logger.setErrStream(perr)


def conn = new ConnectionDetails();


conn.user="logscape"
conn.password="ll4bs"
conn.hostnames="10.28.1.159" 

def qLogger= new QueryLogger(conn,logger)

qLogger.setQuery("select * from  pg_stat_all_indexes ;")
qLogger.write() 
qLogger.writeDeltas() 


def resultSet=[:] 
while(1) {
query="select pg_database.datname, pg_database_size(pg_database.datname) AS size FROM pg_database"
query="select * from pg_stat_all_tables"

        for(def hostname:resultSet.keySet()){
                def sql=resultSet[hostname]["connectionDetails"].sql
                def key="relname"
                def rows=sql.rows(query)
                rows.each {
                        keyName=it[key]
                        newMap[keyName] = it

                        if (oldMap.containsKey(keyName) == true){
                                def delta =  MetricDiffOp.go(oldMap[keyName],newMap[keyName])
                                if (delta!=[:]) {
                                        def row = "host: " + hostname + ", " + key+":"+keyName  + ", " +  delta
                                        logger.log(row.replace("[","").replace("]",""))
                                }
                        }
                        oldMap[keyName]=newMap[keyName]

                }
        }
	println "." 
	sleep(1000)
} 

*/ 
class RowHelper{
	def currData=[:]
	def previousData=[:]
	def deltas=[:] 
	def makeKey(map,keys){
		def key=""
		for(def k:keys){
			key=key+":"+map[k]
		}
		return key
	}
	def update(map,keys) {
		def key=makeKey(map,keys) 
		if (this.currData.containsKey(key)){
			this.deltas[key] =  MetricDiffOp.go(this.currData[key],map)
		} 
		this.currData[key]=map
	}
	def getDeltas(){
		return this.deltas
	}	 
}

class ConnectionDetails {
	def user;
	def password;
	def hostnames;
}
class QueryLogger{
	def connections= [:]
	def properties = null
	def query=null	
	def logger
	def rowHelper = null 	
	def keys = null 
	public QueryLogger(properties,logger){
		this.rowHelper = new RowHelper(); 
		this.properties=properties
		this.logger=logger		
		def defaultUser=properties.user
		def defaultPassword=properties.password 
		for(def hostname:properties.hostnames){
			def url = "jdbc:postgresql://"+hostname+"/postgres?user="+defaultUser+"&password="+defaultPassword+"";
			def sql = Sql.newInstance(url) 
			def serverInfo=new DBServerInfo(defaultUser,defaultPassword,hostname,sql)
			this.connections[hostname]=["connectionDetails":serverInfo] 
		}


	}
	public setKeys(keys) {
		this.keys=keys
	}
	public setQuery(q) { this.query=q } 

	public writeDeltas() {
		def deltas=this.rowHelper.getDeltas()
		for(def hostname:this.connections.keySet()){
			for(def k:deltas.keySet()){
				if (deltas[k].keySet().size() > 1){
					//def row=" host:" + hostname + ", " + deltas[k]  
					//logger.log(row.replace("[","").replace("]",""))

					def dataRow=this.rowHelper.currData[k]
					//def row=" host:" + hostname + ", " + dataRow 
					def row= rowHeader(dataRow,this.keys)  +", " +  deltas[k] 
					logger.log(row.replace("[","").replace("]",""))

				}
			}
		}
	}

	private asMap(row){
		def map=[:]
		for(def k:row.keySet()) { map[k] = row[k] }
		return map 
	}
	public update(){
		def query=this.query
		for(def hostname:this.connections.keySet()){
			def sql=connections[hostname]["connectionDetails"].sql 
			def rows=sql.rows(query)
			rows.each {
				def dataRow = asMap(it)
				dataRow["host"] = hostname 
				this.rowHelper.update(dataRow,this.keys) 
			}
		}
	}

	private rowHeader(map,keys){
		def header=""
		for(def k:keys){
			header=header + ", " + k + ":"+ map[k]  
		}
		return header
	}
	public write() {
		for(def k:this.rowHelper.currData.keySet()){
			def dataRow=this.rowHelper.currData[k]
			def row=" " + dataRow 
			//def row= rowHeader(dataRow,this.keys)  + ", "+ dataRow 
			logger.log(row.replace("[","").replace("]",""))
		}
	} 
	/*
	public write() {
		def query=this.query
		
		for(def hostname:this.connections.keySet()){
			def sql=connections[hostname]["connectionDetails"].sql 
			def rows=sql.rows(query)
			rows.each {
				//sql.eachRow(query) {
				this.rowHelper.update(it,this.keys) 
				def row=" host:" + hostname + ", " +it 
				//logger.log(row.replace("[","").replace("]",""))
				
			}
		}

	}*/
}


